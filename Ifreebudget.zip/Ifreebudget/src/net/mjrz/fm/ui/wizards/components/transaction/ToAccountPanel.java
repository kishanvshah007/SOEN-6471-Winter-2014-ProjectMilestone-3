/*******************************************************************************
 * Copyright  
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/
package net.mjrz.fm.ui.wizards.components.transaction;

import java.util.HashMap;

import net.mjrz.fm.entity.beans.Account;
import net.mjrz.fm.ui.wizards.TransactionWizard;

/**
 * @author iFreeBudget ifreebudget@gmail.com
 * 
 */
public class ToAccountPanel extends FromAccountPanel {

	public ToAccountPanel(TransactionWizard wizard) {
		super(wizard);
	}

	private static final long serialVersionUID = 1L;

	@Override
	public String[][] getValues() {
		String[][] ret = new String[1][1];
		int sel = accountsList.getSelectedIndex();
		String[] row = { "", "" };
		if (sel >= 0) {
			Account a = (Account) accountsList.getSelectedValue();
			row[0] = "TOACCTID";
			row[1] = String.valueOf(a.getAccountId());
		}
		ret[0] = row;
		return ret;
	}

	public void updateComponentUI(HashMap<String, String[][]> values) {
		String[][] value = values.get("TransactionType");
		String[] acctTypes = value[0];
		type = acctTypes[1];
		updateList(type);
	}
}
