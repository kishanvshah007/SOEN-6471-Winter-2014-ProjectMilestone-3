package net.mjrz.fm.search.newfilter;

public interface Filterable {
	public String getSubstitutionString();
	public String getValue();
}
